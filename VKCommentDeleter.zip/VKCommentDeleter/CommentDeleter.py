import asyncio
import os
import re
import traceback
from typing import List, Tuple

import aiovk
from aiovk.exceptions import VkAPIError
from bs4 import BeautifulSoup
from colorama import Fore, Style, init

init(autoreset=True)


class VkCommentDeleter:

    def __init__(self, access_token: str, comments_path: str):
        self.comments_path = comments_path
        self.access_token = access_token
        self.success_count = 0
        self.all_count = 0
        self.api = None

    def _get_posts(self) -> List[str]:
        posts = []
        for filename in os.listdir(self.comments_path):
            if not filename.endswith(".html"):
                continue
            filepath = os.path.join(self.comments_path, filename)
            with open(filepath, "r", encoding="ISO-8859-1") as file:
                content = file.read()
                soup = BeautifulSoup(content, "lxml")
                links = soup.find_all("div", class_="item")
                posts.extend([link.a["href"] for link in links])
        return posts

    def _extract_credentials(self) -> List[Tuple[str, str, str]]:
        posts = self._get_posts()
        self.all_count = len(posts)
        joined_posts = "".join(posts)
        walls = re.findall(r"wall([-]?\d*)", joined_posts)
        replies = re.findall(r"reply=(\d*)", joined_posts)
        return list(zip(walls, replies, posts))

    def _log(self, message: str, color: int, count: int, err: Exception = None) -> None:
        progress = f"[{count:>{len(str(self.all_count))}}/{self.all_count}]"
        print(f"{progress} {color}{message}{Style.RESET_ALL}")
        if err:
            print(f"{Fore.RED}   └> {err}{Style.RESET_ALL}")

    async def _delete_comment(self, owner_id: str, comment_id: str, link: str, count: int) -> None:
        try:
            await self.api.wall.deleteComment(
                owner_id=owner_id, comment_id=comment_id, v="5.131"
            )
            self._log(f"✅ Комментарий успешно удален: {link}", Fore.GREEN, count)
            self.success_count += 1
        except VkAPIError as error:
            if error.error_code in (211, 15):
                self._log(
                    f"⚠️ Комментарий уже удален или нет доступа: {link}",
                    Fore.YELLOW,
                    count,
                )
            elif error.error_code == 15:
                self._log(f"🔒 Доступ к удалению закрыт: {link}", Fore.YELLOW, count)
            else:
                self._log(f"❌ Неизвестная ошибка при удалении: {link}", Fore.RED, count, error)
        except Exception as error:
            self._log(f"🔥 Произошла неожиданная ошибка: {link}", Fore.RED, count, error)

    async def run(self) -> None:
        async with aiovk.TokenSession(access_token=self.access_token) as session:
            self.api = aiovk.API(session)
            credentials = self._extract_credentials()
            tasks = []
            count = 0
            for owner_id, comment_id, link in credentials:
                count += 1
                tasks.append(
                    asyncio.create_task(
                        self._delete_comment(owner_id, comment_id, link, count)
                    )
                )
                if len(tasks) == 3:
                    await asyncio.gather(*tasks)
                    tasks = []
                    await asyncio.sleep(1)
            if tasks:
                await asyncio.gather(*tasks)


def main():
    print(f"{Fore.CYAN}=== VK Comment Deleter ==={Style.RESET_ALL}\n")
    access_token = input(f"{Fore.YELLOW}Введите ваш access token:{Style.RESET_ALL} ")

    script_dir = os.path.dirname(os.path.abspath(__file__))
    comments_dir = os.path.join(script_dir, "comments")

    if os.path.exists(comments_dir) and os.path.isdir(comments_dir):
        comments_path = comments_dir
        print(f"{Fore.GREEN}Папка 'comments' найдена в директории скрипта.{Style.RESET_ALL}")
        print(f"{Fore.GREEN}Используется путь: {comments_path}{Style.RESET_ALL}")
    else:
        comments_path = input(f"{Fore.YELLOW}Введите путь к папке с комментариями:{Style.RESET_ALL} ")

    deleter = VkCommentDeleter(access_token, comments_path)
    try:
        asyncio.run(deleter.run())
        print(f"\n{Fore.GREEN}Удаление завершено!{Style.RESET_ALL}")
        print(f"✅ {Fore.GREEN}Успешно удалено: {deleter.success_count} {Style.RESET_ALL}из {deleter.all_count}")
    except KeyboardInterrupt:
        traceback.print_exc()
        print(f"{Fore.RED}\n\n❌ Процесс прерван пользователем.{Style.RESET_ALL}")
        print(
            f"✅ {Fore.GREEN}Удалено: {deleter.success_count} {Style.RESET_ALL} из {deleter.all_count}"
        )


if __name__ == "__main__":
    main()